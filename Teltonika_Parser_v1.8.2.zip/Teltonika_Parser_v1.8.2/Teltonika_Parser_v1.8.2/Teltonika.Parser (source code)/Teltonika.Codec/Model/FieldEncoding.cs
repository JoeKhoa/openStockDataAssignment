﻿namespace Teltonika.Codec.Model
{
    public enum FieldEncoding
    {
        Int8 = 1,
        Int16 = 2,
        Int32 = 4,
        Int64 = 8,
        Int128 = 16
    }
}
